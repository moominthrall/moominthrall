<?php
require_once("CorrectionMeasureMgmt.php");
?>

<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01//EN">
<HTML LANG="ja">
<HEAD>
<LINK REL="stylesheet" HREF="CorrectionCommon.css" type="text/css">
<META HTTP-EQUIV="Content-Type" CONTENT="text/html; charset=shift_jis">
<META HTTP-EQUIV="Pragma" content="no-cache">
<META HTTP-EQUIV="Cache-Control" content="no-cache">
<META HTTP-EQUIV="Pragma-Directive" content="no-cache">
<META HTTP-EQUIV="Cache-Directive" content="no-cache">
<TITLE>�����[�u�Ǘ� - �����[�u���� -</TITLE>
</HEAD>

<body>
<?php
$CMNum = $_GET["CMNum"]
?>

<!-- �����N�� -->
<table class="link">
<tr><td><a href="ListIndicationScreen.html">�ꗗ�\��</a> | <a href="ObstaclePhenomenonInputScreen.php?TYPE=NewEntry">�V�K�o�^</a> | <a href="In-depthIndicationScreen.php?CMNum=<?php print $CMNum; ?>">�ڍו\��</a> | ��Q���e���� | <a href="CorrectionMeasureInputScreen.php?CMNum=<?php print $CMNum; ?>">�����[�u����</a> | �Ή����ʓ��� | �^�p���ʓ���</td></tr>
</table>
<br>
<form action="DataUpdate.php" method="post" name="CorrectionMeasure" id="CorrectionMeasure" accept-charset="SHIFT_JIS">

<!-- ��ʎ��ʖ� -->
<input type="hidden" name="ScreenIdentifier" value="CorrectionMeasure">
<!-- �����[�u�ԍ� -->
<input type="hidden" name="CorrectionMeasureNumber" value="<?php print $CMNum; ?>">

<!-- ���ʏ�� -->
<?php
$conn_id = DB_OPEN();

// SQL���̐���
$sql  = "SELECT";
$sql .= " a.ConsiderationTimeLimit";				// ��������
$sql .= ", b.FaultManagementNumber";				// ��Q�Ǘ��ԍ�
$sql .= ", a.ChargeDepartmentName";				// �S������
$sql .= ", a.PersonInCharge";					// �S����
$sql .= " FROM ItemTBL a, ObstaclePhenomenonTBL b";
$sql .= " WHERE a.CorrectionMeasureNumber = '".$CMNum."'";
$sql .= " AND a.CorrectionMeasureNumber = b.CorrectionMeasureNumber";

// SQL���s
$result = odbc_exec($conn_id, $sql);
odbc_fetch_row($result, 1);
?>
<table border="0" width="100%">
<tr>
	<td width="50%">
		<table border="0" cellpadding="0">
		<tr>
			<td>
				<table border="1" class="Emphasis" align="left" rules="all">
				<tr>
					<th class="Detail_IDItem">�����[�u�ԍ�</th>
					<td class="Detail_IDItem"><?php print $CMNum;?></td>
				</tr>
				</table>
			</td>
		</tr>
		<tr>
			<td>
				<table border="1" class="Emphasis" align="left" rules="all">
				<tr>
					<th class="Detail_IDItem">��������</th>
<?php
$wk   = odbc_result($result, "ConsiderationTimeLimit");
$wk1  = StrFTime("%Y/%m/%d", DBTime2PHPTime($wk));
?>
					<td class="Detail_IDItem2"><?php print NullDataChenge($wk1);?></td>
				</tr>
				</table>
			</td>
		</tr>
		</table>
	</td>
	<td width="50%">
		<table border="1" cellpadding="0" cellspacing="1" align="right">
		<tr>
			<th class="Detail_ControlItem">��Q�Ǘ��ԍ�</th>
<?php
$wk   = odbc_result($result, "FaultManagementNumber");
?>
			<td class="Detail_ControlItem"><?php print NullDataChenge($wk);?></td>
		</tr>
		<tr>
			<th class="Detail_ControlItem">�S������</th>
<?php
$wk   = odbc_result($result, "ChargeDepartmentName");
?>
			<td class="Detail_ControlItem"><?php print NullDataChenge($wk);?></td>
		</tr>
		<tr>
			<th class="Detail_ControlItem">�S����</th>
<?php
$wk   = odbc_result($result, "PersonInCharge");
?>
			<td class="Detail_ControlItem"><?php print NullDataChenge($wk);?></td>

		</tr>
		</table>
	</td>
</tr>
</table>
<?php
DB_CLOSE($conn_id);
?>

<br>
<!-- �Ǘ����� -->
<?php
$conn_id = DB_OPEN();

// SQL���̐���
$sql  = "SELECT";
$sql .= " a.ConsiderationCompletionDay";			// ����������
$sql .= ", a.CorrespondenceAday";				// �Ή������\���
$sql .= ", a.FirstTimePracticalUseDay";				// �����㏉��^�p��
$sql .= " FROM ItemTBL a";
$sql .= " WHERE a.CorrectionMeasureNumber = '".$CMNum."'";

// SQL���s
$result = odbc_exec($conn_id, $sql);
odbc_fetch_row($result, 1);
?>
<table border="1" rules="all">
<tr>
	<th class="Detail_DataItem">����������</th>
	<td class="Detail_DataItem_Input">
<?php
$wk   = odbc_result($result, "ConsiderationCompletionDay");
$wk1  = StrFTime("%Y", DBTime2PHPTime($wk));
?>
		<input type="text" name="ConsiderationCompletionDayYear" value="<?php print $wk1;?>" size="4" />
		�N
		<select name="ConsiderationCompletionMonth">
			<option value=""></option>
<?php
$wk1  = StrFTime("%m", DBTime2PHPTime($wk));
for ($i=1; $i<=12; $i++) {
	if ($i == $wk1) {
		print "<option value=\"".$i."\" selected>".$i."</option>";
	} else {
		print "<option value=\"".$i."\">".$i."</option>";
	}
}
?>
		</select>
		��
		<select name="ConsiderationCompletionDay">
			<option value=""></option>
<?php
$wk1  = StrFTime("%d", DBTime2PHPTime($wk));
for ($i=1; $i<=31; $i++) {
	if ($i == $wk1) {
		print "<option value=\"".$i."\" selected>".$i."</option>";
	} else {
		print "<option value=\"".$i."\">".$i."</option>";
	}
}
?>
		</select>
		��
	</td>
</tr>
</table>
<table border="1" rules="all">
<tr>
	<th class="Detail_DataItem">�Ή������\���</th>
	<td class="Detail_DataItem_Input">
<?php
$wk   = odbc_result($result, "CorrespondenceAday");
$wk1  = StrFTime("%Y", DBTime2PHPTime($wk));
?>
		<input type="text" name="CorrespondenceAdayYear" value="<?php print $wk1;?>" size="4" />
		�N
		<select name="CorrespondenceAdayMonth">
			<option value=""></option>
<?php
$wk1  = StrFTime("%m", DBTime2PHPTime($wk));
for ($i=1; $i<=12; $i++) {
	if ($i == $wk1) {
		print "<option value=\"".$i."\" selected>".$i."</option>";
	} else {
		print "<option value=\"".$i."\">".$i."</option>";
	}
}
?>
		</select>
		��
		<select name="CorrespondenceAdayDay">
			<option value=""></option>
<?php
$wk1  = StrFTime("%d", DBTime2PHPTime($wk));
for ($i=1; $i<=31; $i++) {
	if ($i == $wk1) {
		print "<option value=\"".$i."\" selected>".$i."</option>";
	} else {
		print "<option value=\"".$i."\">".$i."</option>";
	}
}
?>
		</select>
		��
	</td>
</tr>
</table>

<table border="1" rules="all">
<tr>
	<th class="Detail_DataItem">�����㏉��^�p��</th>
	<td class="Detail_DataItem_Input">
<?php
$wk   = odbc_result($result, "FirstTimePracticalUseDay");
$wk1  = StrFTime("%Y", DBTime2PHPTime($wk));
?>
		<input type="text" name="FirstTimePracticalUseDayYear" value="<?php print $wk1;?>" size="4" />
		�N
		<select name="FirstTimePracticalUseDayMonth">
			<option value=""></option>
<?php
$wk1  = StrFTime("%m", DBTime2PHPTime($wk));
for ($i=1; $i<=12; $i++) {
	if ($i == $wk1) {
		print "<option value=\"".$i."\" selected>".$i."</option>";
	} else {
		print "<option value=\"".$i."\">".$i."</option>";
	}
}
?>
		</select>
		��
		<select name="FirstTimePracticalUseDayDay">
			<option value=""></option>
<?php
$wk1  = StrFTime("%d", DBTime2PHPTime($wk));
for ($i=1; $i<=31; $i++) {
	if ($i == $wk1) {
		print "<option value=\"".$i."\" selected>".$i."</option>";
	} else {
		print "<option value=\"".$i."\">".$i."</option>";
	}
}
?>
		</select>
		��
	</td>
</tr>
</table>
<?php
DB_CLOSE($conn_id);
?>

<br>

<!-- ��Q���� -->
<?php
$conn_id = DB_OPEN();

// SQL���̐���
$sql  = "SELECT";
$sql .= " a.ObstacleContents";				// ��Q���e
$sql .= " FROM ObstaclePhenomenonTBL a, ImportanceTBL b";
$sql .= " WHERE a.CorrectionMeasureNumber = '".$CMNum."'";
$sql .= " AND a.ImportanceCode = b.ImportanceCode";

// SQL���s
$result = odbc_exec($conn_id, $sql);
?>
<table border="0">
<tr>
	<th class="Detail_title" align="left">��Q����</th>
</tr>
</teble>
<table border="1" width="100%" rules="all">
<tr>
	<th class="Detail_DataItem">��Q���e</th>
<?php
$wk   = odbc_result($result, "ObstacleContents");
?>
	<td class="Detail_DataItem"><?php print NullDataChenge($wk);?></td>
</tr>
</table>
<?php
DB_CLOSE($conn_id);
?>

<br>
<!-- �����[�u -->
<?php
$conn_id = DB_OPEN();

// SQL���̐���
$sql  = "SELECT";
$sql .= " a.CorrectionContents";				// �������e
$sql .= ", a.CorrectionPlanOutline";				// �����v��T�v
$sql .= ", a.OutcomeThing";					// ���ʕ�
$sql .= " FROM CorrectionContentsTBL a";
$sql .= " WHERE a.CorrectionMeasureNumber = '".$CMNum."'";

// SQL���s
$result = odbc_exec($conn_id, $sql);
?>
<table border="0">
<tr>
	<th class="Detail_title" align="left">�����[�u</th>
</tr>
<tr>
	<td>
		<table border="1" rules="all">
		<tr>
			<th class="Detail_DataItem">�������e</th>
			<td>
<?php
$wk   = odbc_result($result, "CorrectionContents");
?>
				<textarea name="CorrectionContents" rows="10" cols="119" wrap="virtual"><?php print $wk;?></textarea>
			</td>
		</tr>
		<tr>
			<th class="Detail_DataItem">�����v��T�v</th>
			<td>
<?php
$wk   = odbc_result($result, "CorrectionPlanOutline");
?>
				<textarea name="CorrectionPlanOutline" rows="10" cols="119" wrap="virtual"><?php print $wk;?></textarea>
			</td>
		</tr>
		<tr>
			<th class="Detail_DataItem">���ʕ�</th>
			<td>
<?php
$wk   = odbc_result($result, "OutcomeThing");
?>
				<textarea name="OutcomeThing" rows="5" cols="119" wrap="virtual"><?php print $wk;?></textarea>
			</td>
		</tr>
	</td>
</tr>
</table>
<?php
DB_CLOSE($conn_id);
?>

<br>
<!-- �����[�u�m�F���@ -->
<?php
$conn_id = DB_OPEN();

// SQL���̐���
$sql  = "SELECT";
$sql .= " a.ConfirmationMeans";				// �m�F��i
$sql .= " FROM CorrectionContentsTBL a";
$sql .= " WHERE a.CorrectionMeasureNumber = '".$CMNum."'";

// SQL���s
$result = odbc_exec($conn_id, $sql);
?>
<table border="0" cellpadding="0" cellspacing="1">
<tr>
	<th class="Detail_title" align="left">�����[�u�m�F���@</th>
</tr>
<tr>
	<td>
		<table border="1" rules="all">
		<tr>
			<th class="Detail_DataItem">�m�F��i</th>
			<td>
<?php
$wk   = odbc_result($result, "ConfirmationMeans");
?>
				<textarea name="ConfirmationMeans" rows="10" cols="119" wrap="virtual"><?php print $wk;?></textarea>
			</td>
		</tr>
	</td>
</tr>
</table>
<?php
DB_CLOSE($conn_id);
?>


<br>
<!-- ���l -->
<?php
$conn_id = DB_OPEN();

// SQL���̐���
$sql  = "SELECT";
$sql .= " a.Note";				// ���l
$sql .= " FROM ItemTBL a";
$sql .= " WHERE a.CorrectionMeasureNumber = '".$CMNum."'";

// SQL���s
$result = odbc_exec($conn_id, $sql);
?>
<table border="0">
<tr>
	<th class="Detail_title" align="left">���l</th>
</tr>
<tr>
	<td>
		<table border="1" width="100%" rules="all">
		<tr>
			<td>
<?php
$wk   = odbc_result($result, "Note");
?>
				<textarea name="Note" rows="5" cols="135" wrap="virtual"><?php print $wk;?></textarea>
			</td>
		</tr>
		</table>
	</td>
</tr>
</table>
<?php
DB_CLOSE($conn_id);
?>

<!-- �X�V���s -->
<br>
<table border="0" width="100%">
<tr>
	<td align="right">
		<label>
			<button type="submit" value="Renewal">�����[�u�X�V</button>
		</label>
	</td>
</tr>
</table>

</form>
<br>
<br>
</body>

</html>
