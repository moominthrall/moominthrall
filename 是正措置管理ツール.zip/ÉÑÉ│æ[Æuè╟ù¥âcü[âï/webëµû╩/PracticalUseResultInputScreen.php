<?php
require_once("CorrectionMeasureMgmt.php");
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01//EN">
<HTML LANG="ja">
<HEAD>
<LINK REL="stylesheet" HREF="CorrectionCommon.css" type="text/css">
<META HTTP-EQUIV="Content-Type" CONTENT="text/html; charset=shift_jis">
<META HTTP-EQUIV="Pragma" content="no-cache">
<META HTTP-EQUIV="Cache-Control" content="no-cache">
<META HTTP-EQUIV="Pragma-Directive" content="no-cache">
<META HTTP-EQUIV="Cache-Directive" content="no-cache">
<TITLE>�����[�u�Ǘ� - �^�p���ʓ��� -</TITLE>
</HEAD>

<body>

<!-- �����N�� -->
<table class="link">
<tr><td><a href="ListIndicationScreen.php">�ꗗ�\��</a> | <a href="ObstaclePhenomenonInputScreen.php?TYPE=NewEntry">�V�K�o�^</a> | <a href="In-depthIndicationScreen.php?CMNum=<?php print $CMNum; ?>">�ڍו\��</a> | ��Q���e���� | �����[�u���� | �Ή����ʓ��� | <a href="CorrespondenceResultInputScreen.php?CMNum=<?php print $CMNum; ?>">�^�p���ʓ���</a></td></tr>
</table>
<br>

<!-- ���ʏ�� -->
<?php
$conn_id = DB_OPEN();

// SQL���̐���
$sql  = "SELECT";
$sql .= " a.FirstTimePracticalUseDay";				// �����㏉��^�p��
$sql .= ", a.CorrespondenceCompletionDay";			// �Ή�������
$sql .= ", b.FaultManagementNumber";				// ��Q�Ǘ��ԍ�
$sql .= ", a.ChargeDepartmentName";				// �S������
$sql .= ", a.PersonInCharge";					// �S����
$sql .= " FROM ItemTBL a, ObstaclePhenomenonTBL b";
$sql .= " WHERE a.CorrectionMeasureNumber = '".$CMNum."'";
$sql .= " AND a.CorrectionMeasureNumber = b.CorrectionMeasureNumber";

// SQL���s
$result = odbc_exec($conn_id, $sql);
odbc_fetch_row($result, 1);
?>
<table border="0" width="100%">
<tr>
	<td width="50%">
		<table border="0" cellpadding="0">
		<tr>
			<td>
				<table border="1" class="Emphasis" align="left" rules="all">
				<tr>
					<th class="Detail_IDItem">�����[�u�ԍ�</th>
					<td class="Detail_IDItem"><?php print $CMNum;?></td>
				</tr>
				</table>
			</td>
		</tr>
		<tr>
			<td>
				<table border="1" class="Emphasis" align="left" rules="all">
				<tr>
					<th class="Detail_IDItem">�����㏉��^�p��</th>
<?php
$wk   = odbc_result($result, "FirstTimePracticalUseDay");
$wk1  = StrFTime("%Y/%m/%d", DBTime2PHPTime($wk));
?>
					<td class="Detail_IDItem2"><?php print NullDataChenge($wk1);?></td>
				</tr>
				</table>
			</td>
		</tr>
		</table>
	</td>
	<td width="50%">
		<table border="1" cellpadding="0" cellspacing="1" align="right">
		<tr>
			<th class="Detail_ControlItem">�Ή�������</th>
<?php
$wk   = odbc_result($result, "CorrespondenceCompletionDay");
$wk1  = StrFTime("%Y/%m/%d", DBTime2PHPTime($wk));
?>
			<td class="Detail_ControlItem"><?php print NullDataChenge($wk1);?></td>
		</tr>
		<tr>
			<th class="Detail_ControlItem">��Q�Ǘ��ԍ�</th>
<?php
$wk   = odbc_result($result, "FaultManagementNumber");
?>
			<td class="Detail_ControlItem"><?php print NullDataChenge($wk);?></td>
		</tr>
		<tr>
			<th class="Detail_ControlItem">�S������</th>
<?php
$wk   = odbc_result($result, "ChargeDepartmentName");
?>
			<td class="Detail_ControlItem"><?php print NullDataChenge($wk);?></td>
		</tr>
		<tr>
			<th class="Detail_ControlItem">�S����</th>
<?php
$wk   = odbc_result($result, "PersonInCharge");
?>
			<td class="Detail_ControlItem"><?php print NullDataChenge($wk);?></td>

		</tr>
		</table>
	</td>
</tr>
</table>
<?php
DB_CLOSE($conn_id);
?>


<br>

<!-- ��Q���� -->
<?php
$conn_id = DB_OPEN();

// SQL���̐���
$sql  = "SELECT";
$sql .= " a.ObstacleContents";					// ��Q���e
$sql .= " FROM ObstaclePhenomenonTBL a";
$sql .= " WHERE a.CorrectionMeasureNumber = '".$CMNum."'";

// SQL���s
$result = odbc_exec($conn_id, $sql);
odbc_fetch_row($result, 1);
?>
<table border="0">
<tr>
	<th class="Detail_title" align="left">��Q����</th>
</tr>
	<table border="1" width="100%" rules="all">
	<tr>
		<th class="Detail_DataItem">��Q���e</th>
<?php
$wk   = odbc_result($result, "ObstacleContents");
?>
		<td class="Detail_DataItem"><?php print NullDataChenge($wk);?></td>
	</tr>
	</table>
</tr>
</table>
<?php
DB_CLOSE($conn_id);
?>

<br>
<!-- �����[�u -->
<?php
$conn_id = DB_OPEN();

// SQL���̐���
$sql  = "SELECT";
$sql .= " a.CorrectionContents";					// �������e
$sql .= ", a.CorrectionPlanOutline";					// �����v��T�v
$sql .= ", a.CorrectionPlanResults";					// �����v�����
$sql .= " FROM CorrectionContentsTBL a";
$sql .= " WHERE a.CorrectionMeasureNumber = '".$CMNum."'";

// SQL���s
$result = odbc_exec($conn_id, $sql);
odbc_fetch_row($result, 1);
?>
<table border="0">
<tr>
	<th class="Detail_title" align="left">�����[�u</th>
</tr>
<tr>
	<td>
		<table border="1" rules="all" width="100%">
		<tr>
			<th class="Detail_DataItem">�������e</th>
<?php
$wk   = odbc_result($result, "CorrectionContents");
?>
			<td class="Detail_DataItem"><?php print NullDataChenge($wk);?></td>
		</tr>
		<tr>
			<th class="Detail_DataItem">�����v��T�v</th>
<?php
$wk   = odbc_result($result, "CorrectionPlanOutline");
?>
			<td class="Detail_DataItem"><?php print NullDataChenge($wk);?></td>
		</tr>
		<tr>
			<th class="Detail_DataItem">�����v�����</th>
<?php
$wk   = odbc_result($result, "CorrectionPlanResults");
?>
			<td class="Detail_DataItem"><?php print NullDataChenge($wk);?></td>
		</tr>
	</td>
</tr>
</table>
<?php
DB_CLOSE($conn_id);
?>

<br>
<!-- �����[�u�m�F���@ -->
<?php
$conn_id = DB_OPEN();

// SQL���̐���
$sql  = "SELECT";
$sql .= " a.ConfirmationMeans";						// �m�F��i
$sql .= ", a.CorrespondenceResult";					// �Ή�����
$sql .= ", a.CorrectionEffectPresence";					// �������ʗL��
$sql .= ", a.FirstTimePracticalUseResult";				// ����^�p����
$sql .= " FROM CorrectionContentsTBL a";
$sql .= " WHERE a.CorrectionMeasureNumber = '".$CMNum."'";

// SQL���s
$result = odbc_exec($conn_id, $sql);
odbc_fetch_row($result, 1);
?>
<table border="0" width="100%">
<tr>
	<th class="Detail_title" align="left">�����[�u�m�F���@</th>
</tr>
<tr>
	<td>
		<table border="1" width="100%" rules="all">
		<tr>
			<th class="Detail_DataItem">�m�F��i</th>
<?php
$wk   = odbc_result($result, "ConfirmationMeans");
?>
			<td class="Detail_DataItem"><?php print NullDataChenge($wk);?></td>
		</tr>
		<tr>
			<th class="Detail_DataItem">�Ή�����</th>
<?php
$wk   = odbc_result($result, "CorrespondenceResult");
?>
			<td class="Detail_DataItem"><?php print NullDataChenge($wk);?></td>
		</tr>
		</table>
		<table border="1" rules="all">
		<tr>
			<th class="Detail_DataItem">��������</th>
			<td class="Detail_DataItem_Input">
<?php
$wk   = odbc_result($result, "CorrectionEffectPresence");
?>
				<select name="CorrectionEffect">
					<option value=""></option>
<?php
switch ($wk) {
	case "10":
		print "<option selected value=\"10\">�L</option>";
		print "<option          value=\"20\">��</option>";
		break;
	case "20":
		print "<option          value=\"10\">�L</option>";
		print "<option selected value=\"20\">��</option>";
		break;
	case "":
		print "<option          value=\"10\">�L</option>";
		print "<option          value=\"20\">��</option>";
		break;
}
?>
				</select>
			</td>
		</tr>
		<table border="1" rules="all">
		<tr>
			<th class="Detail_DataItem">����^�p����</th>
			<td class="Detail_DataItem_Input">
<?php
$wk   = odbc_result($result, "FirstTimePracticalUseResult");
?>
				<textarea name="UndiscoveredReason" rows="10" cols="119" wrap="virtual"><?php print $wk;?></textarea>
			</td>
		</tr>
		</table>
	</td>
</tr>
</table>
<?php
DB_CLOSE($conn_id);
?>

<br>
<!-- ���l -->
<?php
$conn_id = DB_OPEN();

// SQL���̐���
$sql  = "SELECT";
$sql .= " a.Note";							// ���l
$sql .= " FROM ItemTBL a";
$sql .= " WHERE a.CorrectionMeasureNumber = '".$CMNum."'";

// SQL���s
$result = odbc_exec($conn_id, $sql);
odbc_fetch_row($result, 1);
?>
<table border="0">
<tr>
	<th class="Detail_title" align="left">���l</th>
</tr>
<tr>
	<td>
		<table border="1" width="100%" rules="all">
		<tr>
			<td class="Detail_DataItem_Input">
<?php
$wk   = odbc_result($result, "Note");
?>
				<textarea name="Note" rows="5" cols="135" wrap="virtual"><?php print $wk;?></textarea>
			</td>
		</tr>
		</table>
	</td>
</tr>
</table>
<?php
DB_CLOSE($conn_id);
?>


<!-- �X�V���s -->
<br>
<table border="0" width="100%">
<tr>
	<td align="right">
		<label>
			<button type="submit" value="Renewal">�^�p���ʍX�V</button>
		</label>
	</td>
</tr>
</table>
<br>
<br>
</body>

</html>
