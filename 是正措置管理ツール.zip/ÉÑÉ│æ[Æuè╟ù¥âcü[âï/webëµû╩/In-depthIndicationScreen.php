<?php
require_once("CorrectionMeasureMgmt.php");
?>

<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01//EN">
<HTML LANG="ja">
<HEAD>
<LINK REL="stylesheet" HREF="CorrectionCommon.css" type="text/css">
<META HTTP-EQUIV="Content-Type" CONTENT="text/html; charset=shift_jis">
<META HTTP-EQUIV="Pragma" content="no-cache">
<META HTTP-EQUIV="Cache-Control" content="no-cache">
<META HTTP-EQUIV="Pragma-Directive" content="no-cache">
<META HTTP-EQUIV="Cache-Directive" content="no-cache">
<TITLE>�����[�u�Ǘ� - �ڍו\�� -</TITLE>
</HEAD>

<body>
<?php
$CMNum = $_GET["CMNum"]
?>


<!-- �����N�� -->
<table class="link">
<tr><td><a href="ListIndicationScreen.php">�ꗗ�\��</a> | <a href="ObstaclePhenomenonInputScreen.php?TYPE=NewEntry">�V�K�o�^</a> | <a href="In-depthIndicationScreen.php?CMNum=<?php print $CMNum; ?>">�ڍו\��</a> | <a href="ObstaclePhenomenonInputScreen.php?TYPE=Renewal&CMNum=<?php print $CMNum; ?>">��Q���e����</a> | <a href="CorrectionMeasureInputScreen.php?CMNum=<?php print $CMNum; ?>">�����[�u����</a> | <a href="CorrespondenceResultInputScreen.php?CMNum=<?php print $CMNum; ?>">�Ή����ʓ���</a> | <a href="PracticalUseResultInputScreen.php?CMNum=<?php print $CMNum; ?>">�^�p���ʓ���</a></td></tr>
</table>
<br>

<!-- ���ʏ�� -->
<?php
$conn_id = DB_OPEN();
?>
<table border="1" class="Emphasis" rules="all" >
<tr>
	<th class="Detail_IDItem">�����[�u�ԍ�</th>
	<td class="Detail_IDItem"><?php print $CMNum;?></td>
</tr>
</table>
<table class="Emphasis" rules="all">
<tr>
	<th class="Detail_IDItem">��</th>
	<td class="Detail_IDItem2"><?php print ProgressAcquisition($conn_id, $CMNum);?></td>
</tr>
</table>
<?php
DB_CLOSE($conn_id);
?>

<!-- �Ǘ����� -->
<?php
$conn_id = DB_OPEN();

// SQL���̐���
$sql  = "SELECT";
$sql .= " a.ObstacleAnalysisInspectionDay";			// ��Q���͌��ؓ�
$sql .= ", a.InnerApprovalDay";					// �������F��
$sql .= ", a.OutsideApprovalDay";				// �S���A���F��
$sql .= ", a.CorrResultInspectionDay";				// �Ή����ʌ��ؓ�
$sql .= ", a.CorrectionCompletionDay";				// ����������
$sql .= ", a.ObstacleAnalysisCompletionDay";			// ��Q���͊�����
$sql .= ", a.ConsiderationTimeLimit";				// ��������
$sql .= ", a.ConsiderationCompletionDay";			// ����������
$sql .= ", a.CorrespondenceADay";				// �Ή������\���
$sql .= ", a.CorrespondenceCompletionDay";			// �Ή�������
$sql .= ", a.FirstTimePracticalUseDay";				// �����㏉��^�p��
$sql .= ", b.FaultManagementNumber";				// ��Q�Ǘ��ԍ�
$sql .= ", a.ChargeDepartmentName";				// �S������
$sql .= ", a.PersonInCharge";					// �S����
$sql .= " FROM ItemTBL a, ObstaclePhenomenonTBL b";
$sql .= " WHERE a.CorrectionMeasureNumber = '".$CMNum."'";
$sql .= " AND a.CorrectionMeasureNumber = b.CorrectionMeasureNumber";

// SQL���s
$result = odbc_exec($conn_id, $sql);
odbc_fetch_row($result, 1);
?>
<br>
<table border="0" width="100%" rules="none">
<tr valign="top">
	<td width="50%">
		<table border="1" class="Detail_ControlItem" align="left" rules="all">
		<tr>
			<th class="Detail_ControlItemImportance">��Q���͌��ؓ�</th>
			<th class="Detail_ControlItemImportance">�������F��</th>
			<th class="Detail_ControlItemImportance">�S���A���F��</th>
			<th class="Detail_ControlItemImportance">�Ή����ʌ��ؓ�</th>
			<th class="Detail_ControlItemImportance">����������</th>
		</tr>
		<tr>
<?php
$wk   = odbc_result($result, "ObstacleAnalysisInspectionDay");
$wk1  = StrFTime("%Y/%m/%d", DBTime2PHPTime($wk));
?>
			<td class="Detail_ControlItemImportance"><?php print NullDataChenge($wk1);?></td>
<?php
$wk   = odbc_result($result, "InnerApprovalDay");
$wk1  = StrFTime("%Y/%m/%d", DBTime2PHPTime($wk));
?>
			<td class="Detail_ControlItemImportance"><?php print NullDataChenge($wk1);?></td>
<?php
$wk   = odbc_result($result, "OutsideApprovalDay");
$wk1  = StrFTime("%Y/%m/%d", DBTime2PHPTime($wk));
?>
			<td class="Detail_ControlItemImportance"><?php print NullDataChenge($wk1);?></td>
<?php
$wk   = odbc_result($result, "CorrResultInspectionDay");
$wk1  = StrFTime("%Y/%m/%d", DBTime2PHPTime($wk));
?>
			<td class="Detail_ControlItemImportance"><?php print NullDataChenge($wk1);?></td>
<?php
$wk   = odbc_result($result, "CorrectionCompletionDay");
$wk1  = StrFTime("%Y/%m/%d", DBTime2PHPTime($wk));
?>
			<td class="Detail_ControlItemImportance"><?php print NullDataChenge($wk1);?></td>
		</tr>
		</table>
	</td>
	<td width="50%">
		<table  class="Detail_ControlItem" align="right" rules="all">
		<tr>
			<th class="Detail_ControlItem">��Q���͊�����</th>
<?php
$wk   = odbc_result($result, "ObstacleAnalysisCompletionDay");
$wk1  = StrFTime("%Y/%m/%d", DBTime2PHPTime($wk));
?>
			<td class="Detail_ControlItem"><?php print NullDataChenge($wk1);?></td>
		</tr>
		<tr>
			<th class="Detail_ControlItem">��������</th>
<?php
$wk   = odbc_result($result, "ConsiderationTimeLimit");
$wk1  = StrFTime("%Y/%m/%d", DBTime2PHPTime($wk));
?>
			<td class="Detail_ControlItem"><?php print NullDataChenge($wk1);?></td>
		</tr>
		<tr>
			<th class="Detail_ControlItem">����������</th>
<?php
$wk   = odbc_result($result, "ConsiderationCompletionDay");
$wk1  = StrFTime("%Y/%m/%d", DBTime2PHPTime($wk));
?>
			<td class="Detail_ControlItem"><?php print NullDataChenge($wk1);?></td>
		</tr>
		<tr>
			<th class="Detail_ControlItem">�Ή������\���</th>
<?php
$wk   = odbc_result($result, "CorrespondenceADay");
$wk1  = StrFTime("%Y/%m/%d", DBTime2PHPTime($wk));
?>
			<td class="Detail_ControlItem"><?php print NullDataChenge($wk1);?></td>
		</tr>
		<tr>
			<th class="Detail_ControlItem">�Ή�������</th>
<?php
$wk   = odbc_result($result, "CorrespondenceCompletionDay");
$wk1  = StrFTime("%Y/%m/%d", DBTime2PHPTime($wk));
?>
			<td class="Detail_ControlItem"><?php print NullDataChenge($wk1);?></td>
		</tr>
		<tr>
			<th class="Detail_ControlItem">�����㏉��^�p��</th>
<?php
$wk   = odbc_result($result, "FirstTimePracticalUseDay");
$wk1  = StrFTime("%Y/%m/%d", DBTime2PHPTime($wk));
?>
			<td class="Detail_ControlItem"><?php print NullDataChenge($wk1);?></td>
		</tr>
		<tr>
			<th class="Detail_ControlItem">��Q�Ǘ��ԍ�</th>
<?php
$wk   = odbc_result($result, "FaultManagementNumber");
?>
			<td class="Detail_ControlItem"><?php print NullDataChenge($wk);?></td>
		</tr>
		<tr>
			<th class="Detail_ControlItem">�S������</th>
<?php
$wk   = odbc_result($result, "ChargeDepartmentName");
?>
			<td class="Detail_ControlItem"><?php print NullDataChenge($wk);?></td>
		</tr>
		<tr>
			<th class="Detail_ControlItem">�S����</th>
<?php
$wk   = odbc_result($result, "PersonInCharge");
?>
			<td class="Detail_ControlItem"><?php print NullDataChenge($wk);?></td>
		</tr>
		</table>
	</td>
</tr>
</table>
<?php
DB_CLOSE($conn_id);
?>

<!-- ��Q���� -->
<?php
$conn_id = DB_OPEN();

// SQL���̐���
$sql  = "SELECT";
$sql .= " a.ObstacleContents";				// ��Q���e
$sql .= ", a.OccurrenceDate";				// ��������
$sql .= ", a.BusinessInfluentialPresence";		// �Ɩ��e��
$sql .= ", b.ImportanceName";				// �d�v�x
$sql .= ", a.OutlineAndInfluence";			// �T�v�E�e��
$sql .= ", a.PassageAndCorrespondence";			// �o�߁E�Ή�
$sql .= ", a.TellingPresence";				// ���񍐗L��
$sql .= ", a.TellingDate";				// ���񍐓���
$sql .= ", a.ReportWithinNextDay";			// �����ȓ��񍐗L��
$sql .= " FROM ObstaclePhenomenonTBL a, ImportanceTBL b";
$sql .= " WHERE a.CorrectionMeasureNumber = '".$CMNum."'";
$sql .= " AND a.ImportanceCode = b.ImportanceCode";

// SQL���s
$result = odbc_exec($conn_id, $sql);
?>
<table border="0" width="100%">
<tr>
	<th class="Detail_title" align="left">��Q����</th>
</tr>
<tr>
	<td>
		<table rules="all">
		<tr>
			<th class="Detail_DataItem">��Q�敪</th>
		</tr>
		</table>
		<table width="100%" rules="all">
		<tr>
			<th class="Detail_DataItem">��Q���e</th>
<?php
$wk   = odbc_result($result, "ObstacleContents");
?>
			<td class="Detail_DataItem"><?php print NullDataChenge($wk);?></td>
		</tr>
		</table>
		<table rules="all">
		<tr>
			<th class="Detail_DataItem">�����i���m�j����</th>
<?php
$wk   = DBTime2PHPTime(odbc_result($result, "OccurrenceDate"));
?>
			<td class="Detail_DataDateItem"><?php print NullDataChenge(StrFTime("%Y/%m/%d %H:%M", $wk));?></td>
		</tr>
		</table>
		<table rules="all">
		<tr>
			<th class="Detail_DataItem">�Ɩ��e��</th>
<?php
$wk   = odbc_result($result, "BusinessInfluentialPresence");
if($wk == "10") {
	print "<td class=\"Detail_DataYesNoItem\">�L��</td>";
} else {
	print "<td class=\"Detail_DataYesNoItem\">����</td>";
}
?>
		</tr>
		</table>
		<table rules="all">
		<tr>
			<th class="Detail_DataItem">�d�v�x</th>
<?php
$wk   = odbc_result($result, "ImportanceName");
?>
			<td class="Detail_DataYesNoItem"><?php print NullDataChenge($wk);?></td>
		</tr>
		</table>
		<table width="100%" rules="all">
		<tr>
			<th class="Detail_DataItem">�T�v/�e��</th>
<?php
$wk   = odbc_result($result, "OutlineAndInfluence");
print "<td class=\"Detail_DataItem\">".NullDataChenge($wk)."</td>";
?>
		</tr>
		<tr>
			<th class="Detail_DataItem">�o��/�Ή�</th>
<?php
$wk   = odbc_result($result, "PassageAndCorrespondence");
print "<td class=\"Detail_DataItem\">".NullDataChenge($wk)."</td>";
?>
		</tr>
		</table>
		<table rules="all">
		<tr>
			<th class="Detail_DataItem">1���Ԉȓ��񍐁i���j</th>
<?php
$wk   = odbc_result($result, "TellingPresence");
if($wk == "10") {
	print "<td class=\"Detail_DataYesNoItem\">�L��</td>";
} else {
	print "<td class=\"Detail_DataYesNoItem\">����</td>";
}
?>
			<th class="Detail_DataItem">����</th>
<?php
$wk   = DBTime2PHPTime(odbc_result($result, "TellingDate"));
?>
			<td class="Detail_DataDateItem"><?php print NullDataChenge(StrFTime("%Y/%m/%d %H:%M", $wk));?></td>
		</tr>
		</table>
		<table rules="all">
		<tr>
			<th class="Detail_DataItem">�����ȓ��񍐁i�����j</th>
<?php
$wk   = odbc_result($result, "ReportWithinNextDay");
if($wk == "10") {
	print "<td class=\"Detail_DataYesNoItem\">�L��</td>";
} else {
	print "<td class=\"Detail_DataYesNoItem\">����</td>";
}
?>
		</tr>
		</table>
	</td>
</tr>
</table>
<?php
DB_CLOSE($conn_id);
?>

<!-- �������� -->
<?php
$conn_id = DB_OPEN();

// SQL���̐���
$sql  = "SELECT";
$sql .= " a.DirectCause";						// ���ڌ���
$sql .= ", a.UndiscoveredReason";					// ���������R
$sql .= ", a.FoundationCause";						// ���{����
$sql .= " FROM ObstacleAnalysisTBL a";
$sql .= " WHERE a.CorrectionMeasureNumber = '".$CMNum."'";

// SQL���s
$result = odbc_exec($conn_id, $sql);
?>
<br>
<table border="0" cellpadding="0" cellspacing="1" width="100%">
<tr>
	<th class="Detail_title" align="left">��������</th>
</tr>
<tr>
	<td>
		<table rules="all">
		<tr>
			<th class="Detail_DataItem">���ڌ����敪</th>
		</tr>
		</table>
		<table width="100%" rules="all">
		<tr>
			<th class="Detail_DataItem">���ڌ���</th>
<?php
$wk   = odbc_result($result, "DirectCause");
print "<td class=\"Detail_DataItem\">".NullDataChenge($wk)."</td>";
?>
		</tr>
		<tr>
			<th class="Detail_DataItem">���������R</th>
<?php
$wk   = odbc_result($result, "UndiscoveredReason");
print "<td class=\"Detail_DataItem\">".NullDataChenge($wk)."</td>";
?>
		</tr>
		<table rules="all">
		<tr>
			<th class="Detail_DataItem">���{�����敪</th>
		</tr>
		</table>
		<table width="100%" rules="all">
		<tr>
			<th class="Detail_DataItem">���{����</th>
<?php
$wk   = odbc_result($result, "FoundationCause");
print "<td class=\"Detail_DataItem\">".NullDataChenge($wk)."</td>";
?>
		</tr>
		</table>
	</td>
</tr>
</table>
<?php
DB_CLOSE($conn_id);
?>

<!-- �����[�u -->
<?php
$conn_id = DB_OPEN();

// SQL���̐���
$sql  = "SELECT";
$sql .= " a.CorrectionContents";					// �������e
$sql .= ", a.CorrectionPlanOutline";					// �����v��T�v
$sql .= ", a.CorrectionPlanResults";					// �����v�����
$sql .= ", a.OutcomeThing";						// ���ʕ�
$sql .= " FROM CorrectionContentsTBL a";
$sql .= " WHERE a.CorrectionMeasureNumber = '".$CMNum."'";

// SQL���s
$result = odbc_exec($conn_id, $sql);
?>
<br>
<table border="0" cellpadding="0" cellspacing="1" width="100%">
<tr>
	<th class="Detail_title" align="left">�����[�u</th>
</tr>
<tr>
	<td>
		<table width="100%" rules="all">
		<tr>
			<th class="Detail_DataItem">�������e</th>
<?php
$wk   = odbc_result($result, "CorrectionContents");
?>
			<td class="Detail_DataItem"><?php print NullDataChenge($wk);?></td>
		</tr>
		<tr>
			<th class="Detail_DataItem">�����v��T�v</th>
<?php
$wk   = odbc_result($result, "CorrectionPlanOutline");
?>
			<td class="Detail_DataItem"><?php print NullDataChenge($wk);?></td>
		</tr>
		<tr>
			<th class="Detail_DataItem">�����v�����</th>
<?php
$wk   = odbc_result($result, "CorrectionPlanResults");
?>
			<td class="Detail_DataItem"><?php print NullDataChenge($wk);?></td>
		</tr>
		<tr>
			<th class="Detail_DataItem">���ʕ�</th>
<?php
$wk   = odbc_result($result, "OutcomeThing");
?>
			<td class="Detail_DataItem"><?php print NullDataChenge("");?></td>
		</tr>
		</table>
	</td>
</tr>
</table>
<?php
DB_CLOSE($conn_id);
?>

<!-- �����[�u���� -->
<?php
$conn_id = DB_OPEN();

// SQL���̐���
$sql  = "SELECT";
$sql .= " a.ConfirmationMeans";						// �m�F��i
$sql .= ", a.CorrespondenceResult";					// �Ή�����
$sql .= ", a.CorrectionEffectPresence";					// �������ʗL��
$sql .= ", a.FirstTimePracticalUseResult";				// ����^�p����
$sql .= " FROM CorrectionContentsTBL a";
$sql .= " WHERE a.CorrectionMeasureNumber = '".$CMNum."'";

// SQL���s
$result = odbc_exec($conn_id, $sql);
?>
<br>
<table border="0" cellpadding="0" cellspacing="0" width="100%">
<tr>
	<th class="Detail_title" align="left">�����[�u���ʁi�L�����m�F�E�]���j</th>
</tr>
<tr>
	<td>
		<table width="100%" rules="all">
		<tr>
			<th class="Detail_DataItem">�m�F��i</th>
<?php
$wk   = odbc_result($result, "ConfirmationMeans");
?>
			<td class="Detail_DataItem"><?php print NullDataChenge($wk);?></td>
		</tr>
		<tr>
			<th class="Detail_DataItem">�Ή�����</th>
<?php
$wk   = odbc_result($result, "CorrespondenceResult");
?>
			<td class="Detail_DataItem"><?php print NullDataChenge($wk);?></td>
		</tr>
		</table>
		<table rules="all">
		<tr>
			<th class="Detail_DataItem">��������</th>
<?php
$wk   = odbc_result($result, "CorrectionEffectPresence");
switch($wk) {
	case "10":
		print "<td class=\"Detail_DataYesNoItem\">�L��</td>";
		break;
	case "20":
		print "<td class=\"Detail_DataYesNoItem\">����</td>";
		break;
	default:
		print "<td class=\"Detail_DataYesNoItem\">".NullDataChenge("")."</td>";
}
?>
		</tr>
		</table>
		<table width="100%" rules="all">
		<tr>
			<th class="Detail_DataItem">����^�p����</th>
<?php
$wk   = odbc_result($result, "FirstTimePracticalUseResult");
?>
			<td class="Detail_DataItem"><?php print NullDataChenge($wk);?></td>
		</tr>
		</table>
	</td>
</tr>
</table>
<?php
DB_CLOSE($conn_id);
?>

<!-- ���l -->
<?php
$conn_id = DB_OPEN();

// SQL���̐���
$sql  = "SELECT";
$sql .= " a.Note";						// ���l
$sql .= " FROM ItemTBL a";
$sql .= " WHERE a.CorrectionMeasureNumber = '".$CMNum."'";

// SQL���s
$result = odbc_exec($conn_id, $sql);
?>
<br>
<table border="0" cellpadding="0" cellspacing="0" width="100%">
<tr>
	<th class="Detail_title" align="left">���l</th>
</tr>
<tr>
	<td>
		<table width="100%" rules="all">
		<tr>
<?php
$wk   = odbc_result($result, "Note");
?>
			<td class="Detail_DataItem"><?php print NullDataChenge($wk);?></td>
		</tr>
		</table>
	</td>
</tr>
</table>
<?php
DB_CLOSE($conn_id);
?>

<!-- �Г���� -->
<?php
$conn_id = DB_OPEN();

// SQL���̐���
$sql  = "SELECT";
$sql .= " b.ContractConfirmation AS ContractConfirmation";				// �_��`��
$sql .= ", a.OperationalNotificationNumber AS OperationalNotificationNumber";		// ��ƒʒm���ԍ�
$sql .= ", b.AppropriationDepartmentOfSales AS AppropriationDepartmentOfSales";		// ����v�㕔��
$sql .= " FROM ItemTBL a, OperationalNoticeTBL b";
$sql .= " WHERE a.CorrectionMeasureNumber = '".$CMNum."'";
$sql .= " AND a.OperationalNotificationNumber = b.OperationalNotificationNumber";

// SQL���s
$result = odbc_exec($conn_id, $sql);
?>
<br>
<table border="0" cellpadding="0" cellspacing="1">
<tr>
	<th class="Detail_title" align="left">��Q������Ƃ̌_��`��</th>
</tr>
	<td>
		<table rules="all">
		<tr>
			<th class="Detail_DataItem2">�_��`��</th>
			<th class="Detail_DataItem2">��ƒʒm���ԍ�</th>
			<th class="Detail_DataItem2">����v�㕔��</th>
		</tr>
		<tr>
<?php
$wk  = odbc_result($result, "ContractConfirmation");
?>
			<td class="Detail_DataItem"><?php print NullDataChenge($wk);?></td>
<?php
$wk  = odbc_result($result, "OperationalNotificationNumber");
?>
			<td class="Detail_DataItem"><?php print NullDataChenge($wk);?></td>
<?php
$wk  = odbc_result($result, "AppropriationDepartmentOfSales");
?>
			<td class="Detail_DataItem"><?php print NullDataChenge($wk);?></td>
		</tr>
		</table>
	</td>
</tr>
</table>
<?php
DB_CLOSE($conn_id);
?>

</body>

</html>
