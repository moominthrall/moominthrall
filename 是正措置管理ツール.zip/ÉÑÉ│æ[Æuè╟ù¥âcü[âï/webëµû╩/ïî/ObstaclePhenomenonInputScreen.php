<?php
require_once("CorrectionMeasureMgmt.php");
?>

<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01//EN">
<HTML LANG="ja">
<HEAD>
<LINK REL="stylesheet" HREF="CorrectionCommon.css" type="text/css">
<META HTTP-EQUIV="Content-Type" CONTENT="text/html; charset=SHIFT_JIS">
<META HTTP-EQUIV="Pragma" content="no-cache">
<META HTTP-EQUIV="Cache-Control" content="no-cache">
<META HTTP-EQUIV="Pragma-Directive" content="no-cache">
<META HTTP-EQUIV="Cache-Directive" content="no-cache">
<TITLE>�����[�u�Ǘ� - 
<?php
$MTYPE = $_GET["TYPE"];

if ($MTYPE=="NewEntry") {
	print "�V�K�o�^";
} elseif ($MTYPE=="Renewal") {
	print "��Q���e����";
} else {
}
?>
 -
</TITLE>
</HEAD>

<BODY>

<!-- �����N�� -->
<table>
<tr><td><a href="ListIndicationScreen.php">�ꗗ�\��</a> | <a href="ObstaclePhenomenonInputScreen.php?TYPE=NewEntry">�V�K�o�^</a> | �ڍו\�� | ��Q���e���� | �����[�u���� | �������ʓ���</td></tr>
</table>
<br>
<form action="ObstacleInputCheck.php" method="post" name="ObstacleInput" id="ObstacleInput" accept-charset="SHIFT_JIS">

<?php
if ($MTYPE=="NewEntry") {	// ��Q���ېV�K�o�^
	print "<!-- ��Q�Ǘ�DB�G�N�X�|�[�g�f�[�^����荞�� -->";
	print "<br>";
	print "<table border=\"0\" width=\"100%\">";
	print "<tr>";
	print "<td align=\"right\">";
	print "<label>";
	print "<button type=\"submit\" value=\"FaultManageDBImport\">��Q�Ǘ�DB�G�N�X�|�[�g�f�[�^��荞��</button>";
	print "</label>";
	print "</td>";
	print "</tr>";
	print "</table>";
} elseif ($MTYPE=="Renewal") {	// ��Q���ۍX�V
	print "<!-- ���ʏ�� -->";
	print "<table border=\"1\" class=\"Emphasis\" rules=\"all\">";
	print "<tr>";
	print "<th class=\"Detail_IDItem\">�����[�u�ԍ�</th>";
	print "<td class=\"Detail_IDItem\">�f�[�^�O�O</td>";
	print "</tr>";
	print "</table>";
	print "<table border=\"1\" class=\"Emphasis\" rules=\"all\">";
	print "<tr>";
	print "<th class=\"Detail_IDItem\">��������</th>";
	print "<td class=\"Detail_IDItem2\">�f�[�^�O�P</td>";
	print "</tr>";
	print "</table>";
}
?>

<!-- �Ǘ����� -->
<br>
<table border="0" cellpadding="0" cellspacing="1">
<tr>
	<th>��Q�Ǘ��ԍ�</th>
	<td>
		<input type="text" name="FaultManageNum" size="120px" value="" />
	</td>
</tr>
<tr>
	<th>�S������</th>
	<td>
		<select name="DepartmentName">
			<option value=""></option>
<?php
$conn_id = DB_OPEN();
$sql = "select * from DepartmentTBL";
$result = odbc_exec($conn_id, $sql);
$rows = 1;
while(odbc_fetch_row($result, $rows++)) {
	$d_code = odbc_result($result, "DepartmentCode");
	$d_name = odbc_result($result, "DepartmentName");
	print "<OPTION VALUE=".$d_code.">".$d_name."</OPTION>";
}

DB_CLOSE($conn_id);
?>
		</select>
	</td>
	<th>�S����</th>
	<td>
		<input type="text" name="PersonInCharge" size="120px" value="" />
	</td>

</tr>
</table>
<br>

<!-- ��Q���� -->
<table border="0" cellpadding="0" cellspacing="1">
<tr>
	<th align="left">��Q����</th>
</tr>
<tr>
	<td>
		<table border="1" rules="all">
		<tr>
			<th class="Detail_DataItem">��Q�敪</th>
			<td>
				<select name="FaultDivision">
					<option value=""></option>
					<option value="">..</option>
					<option value="">...</option>
				</select>
			</td>
		</tr>
		</table>
		<table border="1" rules="all">
		<tr>
			<th class="Detail_DataItem">��Q���e</th>
			<td>
				<textarea name="FaultContents" rows="3" cols="120" wrap="virtuala"></textarea>
			</td>
		</tr>
		</table>
		<table border="1" rules="all">
		<tr>
			<th class="Detail_DataItem">�����i���m�j����</th>
			<td align="center">
<?php
// �N�ɂ͓����̐���N��ݒ肷��
print "<input type=\"text\" name=\"DateOfOccurrenceYear\" value=".StrFTime("%Y")." size=\"4\" />"
?>
				�N
				<select name="DateOfOccurrenceMonth">
					<option value=""></option>
<?php
for ($i=1; $i <=12; $i++) {
	print "<OPTION VALUE=".$i.">".$i."</OPTION>";
}
?>
				</select>
				��
				<select name="DateOfOccurrenceDay">
					<option value=""></option>
<?php
for ($i=1; $i <=31; $i++) {
	print "<OPTION VALUE=".$i.">".$i."</OPTION>";
}
?>
				</select>
				��
			</td>
			<td align="center">
				<select name="DateOfOccurrenceHour">
					<option value=""></option>
<?php
for ($i=0; $i <=23; $i++) {
	print "<OPTION VALUE=".SPrintF("%02d", $i).">".SPrintF("%02d", $i)."</OPTION>";
}
?>
				</select>
				��
				<select name="DateOfOccurrenceMinute">
					<option value=""></option>
<?php
for ($i=0; $i <=59; $i++) {
	print "<OPTION VALUE=".SPrintF("%02d", $i).">".SPrintF("%02d", $i)."</OPTION>";
}
?>
				</select>
				��
			</td>
		</tr>
		</table>
		<table border="1" rules="all">
		<tr>
			<th class="Detail_DataItem">�Ɩ��e��</th>
			<td>
				<select name="InfluentialPresence">
					<option value=""></option>
					<option value="10">�L</option>
					<option value="20">��</option>
				</select>
			</td>
		</tr>
		</table>
		<table border="1" rules="all">
		<tr>
			<th class="Detail_DataItem">�d�v�x</th>
			<td>
				<select name="Importance">
					<option value=""></option>
					<option value="10">��</option>
					<option value="20">��</option>
					<option value="30">��</option>
				</select>
			</td>
		</tr>
		</table>
		<table border="1" width="100%" rules="all">
		<tr>
			<th class="Detail_DataItem">�T�v/�e��</th>
			<td>
				<textarea name="Outline" rows="10" cols="120" wrap="virtual"></textarea>
			</td>
		</tr>
		<tr>
			<th class="Detail_DataItem">�o��/�Ή�</th>
			<td>
				<textarea name="Passage" rows="10" cols="120" wrap="virtual"></textarea>
			</td>
		</tr>
		</table>
		<table border=1 rules="all">
		<tr>
			<th class="Detail_DataItem">1���Ԉȓ��񍐁i���j</th>
			<td>
				<select name="Telling">
					<option value=""></option>
					<option value="10">�L</option>
					<option value="20">��</option>
				</select>
			</td>
			<th class="Detail_DataItem">����</th>
			<td>
			<td align="center">
				<input type="text" name="TellingYear" value="" size="4" />
				�N
				<select name="TellingMonth">
					<option value=""></option>
<?php
for ($i=1; $i <=12; $i++) {
	print "<OPTION VALUE=".$i.">".$i."</OPTION>";
}
?>
				</select>
				��
				<select name="TellingDay">
					<option value=""></option>
<?php
for ($i=1; $i <=31; $i++) {
	print "<OPTION VALUE=".$i.">".$i."</OPTION>";
}
?>
				</select>
				��
			</td>
			<td align="center">
				<select name="TellingHour">
					<option value=""></option>
<?php
for ($i=0; $i <=23; $i++) {
	print "<OPTION VALUE=".SPrintF("%02d", $i).">".SPrintF("%02d", $i)."</OPTION>";
}
?>
				</select>
				��
				<select name="TellingMinute">
					<option value=""></option>
<?php
for ($i=0; $i <=59; $i++) {
	print "<OPTION VALUE=".SPrintF("%02d", $i).">".SPrintF("%02d", $i)."</OPTION>";
}
?>
				</select>
				��
			</td>
		</tr>
		</table>
		<table border="1" rules="all">
		<tr>
			<th class="Detail_DataItem">�����ȓ��񍐁i�����j</th>
			<td>
				<select name="Report">
					<option value=""></option>
					<option value="10">�L</option>
					<option value="20">��</option>
				</select>
			</td>
		</tr>
		</table>
	</td>
</tr>
</table>

<!-- �������� -->
<br>
<table border="0" cellpadding="0" cellspacing="1">
<tr>
	<th align="left">��������</th>
</tr>
<tr>
	<td>
		<table border="1" rules="all">
		<tr>
			<th class="Detail_DataItem">���ڌ����敪</th>
			<td>
				<select name="DirectCauseDivision">
					<option value=""></option>
					<option value="10">...</option>
					<option value="20">....</option>
				</select>
			</td>
		</tr>
		</table>
		<table border="1" rules="all">
		<tr>
			<th class="Detail_DataItem">���ڌ���</th>
			<td>
				<textarea name="DirectCause" rows="10" cols="120" wrap="virtual"></textarea>
			</td>
		</tr>
		<tr>
			<th class="Detail_DataItem">���������R</th>
			<td>
				<textarea name="UndiscoveredReason" rows="10" cols="120" wrap="virtual"></textarea>
			</td>
		</tr>
		<table border="1" rules="all">
		<tr>
			<th class="Detail_DataItem">���{�����敪</th>
			<td>
				<select name="FoundationCauseDivision">
					<option value=""></option>
					<option value="10">...</option>
					<option value="20">....</option>
				</select>
			</td>
		</tr>
		</table>
		<table border="1" rules="all">
		<tr>
			<th class="Detail_DataItem">���{����</th>
			<td>
				<textarea name="FoundationCause" rows="10" cols="120"  wrap="virtual"></textarea>
			</td>
		</tr>
		</table>
	</td>
</tr>
</table>


<!-- ���l -->
<br>
<table border="0" cellpadding="0" cellspacing="0">
<tr>
	<th align="left">���l</th>
</tr>
<tr>
	<td>
		<table border="1" width="100%" rules="all">
		<tr>
			<td>
				<textarea name="Note" rows="5" cols="135" wrap="virtual"></textarea>
			</td>
		</tr>
		</table>
	</td>
</tr>
</table>

<!-- �Г���� -->
<br>
<table border="0">
<tr>
	<th align="left">��Q������Ƃ̌_��`��</th>
</tr>
<tr>
	<td>
		<table border="1" rules="all">
		<tr>
			<th class="Detail_DataItem2">�_��`��</th>
			<th class="Detail_DataItem2">����</th>
		</tr>
<?php
$conn_id = DB_OPEN();
$sql = "select * from OperationalNoticeTBL";
$result = odbc_exec($conn_id, $sql);
$rows = 1;
while(odbc_fetch_row($result, $rows++)) {
	$o_code = odbc_result($result, "OperationalNotificationNumber");
	$o_conf = odbc_result($result, "ContractConfirmation");
	$o_Expl = odbc_result($result, "Explanation");
	print "<tr>";
	print "<td class=\"Detail_DataItem_Input\">";
	print "<label><input type=\"radio\" name=\"OperationalNotification\" value=".$o_code.">".$o_conf."</label>";
	print "<td class=\"Detail_DataItem_Input\">".$o_Expl."</td>";
	print "</td>";
	print "</tr>";
}
DB_CLOSE($conn_id);
?>
		</table>
	</td>
</tr>
</table>

<!-- �o�^���s -->
<br>
<table border="0" width="100%">
<tr>
	<td align="right">
		<label>
<?php
if ($MTYPE=="NewEntry") {	// ��Q���ېV�K�o�^
	print	"<button type=\"submit\" value=\"NewEntry\">��Q�o�^</button>";
} elseif ($MTYPE=="Renewal") {	// ��Q���ۍX�V
	print	"<button type=\"submit\" value=\"Renewal\">��Q���e�X�V</button>";
}
?>
		</label>
	</td>
</tr>
</table>

</form>
<br>
<br>
</body>

</html>
