<?php
require_once("CorrectionMeasureMgmt.php");
?>

<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01//EN">
<HTML LANG="ja">
<HEAD>
<LINK REL="stylesheet" HREF="CorrectionCommon.css" type="text/css">
<META HTTP-EQUIV="Content-Type" CONTENT="text/html; charset=shift_jis">
<META HTTP-EQUIV="Pragma" content="no-cache">
<META HTTP-EQUIV="Cache-Control" content="no-cache">
<META HTTP-EQUIV="Pragma-Directive" content="no-cache">
<META HTTP-EQUIV="Cache-Directive" content="no-cache">
<TITLE>�ڍו\��</TITLE>
</HEAD>

<body>
<?php
$CMNum = $_GET["CMNum"]
?>


<!-- �����N�� -->
<table>
<tr><td><a href="ListIndicationScreen.php">�ꗗ�\��</a> | <a href="ObstaclePhenomenonInputScreen.php?TYPE=NewEntry">�V�K�o�^</a> | <a href="In-depthIndicationScreen.php?CMNum=<?php print $CMNum; ?>">�ڍו\��</a> | <a href="ObstaclePhenomenonInputScreen.php?TYPE=Renewal&CMNum=<?php print $CMNum; ?>">��Q���e����</a> | <a href="CorrectionMeasureInputScreen.php?CMNum=<?php print $CMNum; ?>">�����[�u����</a> | <a href="CorrectionResultInputScreen.php?CMNum=<?php print $CMNum; ?>">�������ʓ���</a></td></tr>
</table>
<br>

<!-- ���ʏ�� -->
<?php
$conn_id = DB_OPEN();
?>
<table border="1" class="Emphasis" rules="all" >
<tr>
	<th class="Detail_IDItem">�����[�u�ԍ�</th>
<?php
print "<td class=\"Detail_IDItem\">".$CMNum."</td>";
?>
</tr>
</table>
<table class="Emphasis" rules="all">
<tr>
	<th class="Detail_IDItem">��</th>
	<td class="Detail_IDItem2"><?php print ProgressAcquisition($conn_id, $CMNum);?></td>
</tr>
</table>
<?php
DB_CLOSE($conn_id);
?>

<!-- �Ǘ����� -->
<?php
$conn_id = DB_OPEN();

// SQL���̐���
$sql  = "SELECT";
$sql .= " a.ConsiderationCompletionDay";			// �O���[�v������������
$sql .= ", a.InnerApprovalDay";					// �������F��
$sql .= ", a.OutsideApprovalDay";				// �S���A���F��
$sql .= ", a.CorrectionMeasureCompletionDay";			// �����[�u������
$sql .= ", a.ConsiderationTimeLimit";				// ��������
$sql .= ", a.CorrectionMeasureAday";				// �����[�u�����\���
$sql .= ", a.ChargeDepartmentName";				// �S������
$sql .= ", b.FaultManagementNumber";				// ��Q�Ǘ��ԍ�
$sql .= ", a.PersonInCharge";					// �S����
$sql .= " FROM ItemTBL a, ObstaclePhenomenonTBL b";
$sql .= " WHERE a.CorrectionMeasureNumber = '".$CMNum."'";
$sql .= " AND a.CorrectionMeasureNumber = b.CorrectionMeasureNumber";

// SQL���s
$result = odbc_exec($conn_id, $sql);
?>
<br>
<table border="0" width="100%" rules="none">
<tr valign="top">
	<td width="50%">
		<table border="1" class="Detail_ControlItem" align="left" rules="all">
		<tr>
			<th class="Detail_ControlItem">����������</th>
			<th class="Detail_ControlItem">�������F��</th>
			<th class="Detail_ControlItem">�S���A���F��</th>
			<th class="Detail_ControlItem">�����[�u������</th>
		</tr>
		<tr>
<?php
odbc_fetch_row($result, 1);

$wk   = odbc_result($result, "ConsiderationCompletionDay");
$d1   = StrFTime("%Y/%m/%d", DBTime2PHPTime($wk));

$wk   = odbc_result($result, "InnerApprovalDay");
$d2   = StrFTime("%Y/%m/%d", DBTime2PHPTime($wk));

$wk   = odbc_result($result, "OutsideApprovalDay");
$d3   = StrFTime("%Y/%m/%d", DBTime2PHPTime($wk));

$wk   = odbc_result($result, "CorrectionMeasureCompletionDay");
$d4   = StrFTime("%Y/%m/%d", DBTime2PHPTime($wk));

print "<td class=\"Detail_ControlItemDate\">".NullDataChenge($d1)."</td>";
print "<td class=\"Detail_ControlItemDate\">".NullDataChenge($d2)."</td>";
print "<td class=\"Detail_ControlItemDate\">".NullDataChenge($d3)."</td>";
print "<td class=\"Detail_ControlItemDate\">".NullDataChenge($d4)."</td>";
?>
		</tr>
		</table>
	</td>
	<td width="50%">
		<table  class="Detail_ControlItem" align="right" rules="all">
		<tr>
			<th class="Detail_ControlItem">��������</th>
<?php
$wk   = odbc_result($result, "ConsiderationTimeLimit");
$d1   = StrFTime("%Y/%m/%d", DBTime2PHPTime($wk));
print "<td class=\"Detail_ControlItem\">".NullDataChenge($d1)."</td>";
?>
		</tr>
		<tr>
			<th class="Detail_ControlItem">�����[�u�����\���</th>
<?php
$wk   = odbc_result($result, "CorrectionMeasureAday");
print "<td class=\"Detail_ControlItem\">".NullDataChenge($wk)."</td>";
?>
		</tr>
		<tr>
			<th class="Detail_ControlItem">��Q�Ǘ��ԍ�</th>
<?php
$wk   = odbc_result($result, "FaultManagementNumber");
print "<td class=\"Detail_ControlItem\">".NullDataChenge($wk)."</td>";
?>
		</tr>
		<tr>
			<th class="Detail_ControlItem">�S������</th>
<?php
$wk   = odbc_result($result, "ChargeDepartmentName");
print "<td class=\"Detail_ControlItem\">".NullDataChenge($wk)."</td>";
?>
		</tr>
		<tr>
			<th class="Detail_ControlItem">�S����</th>
<?php
$wk   = odbc_result($result, "PersonInCharge");
print "<td class=\"Detail_ControlItem\">".NullDataChenge($wk)."</td>";
?>
		</tr>
		</table>
	</td>
</tr>
</table>
<?php
DB_CLOSE($conn_id);
?>

<!-- ��Q���� -->
<?php
$conn_id = DB_OPEN();

// SQL���̐���
$sql  = "SELECT";
$sql .= " a.ObstacleContents";				// ��Q���e
$sql .= ", a.OccurrenceDate";				// ��������
$sql .= ", a.BusinessInfluentialPresence";		// �Ɩ��e��
$sql .= ", b.ImportanceName";				// �d�v�x
$sql .= ", a.OutlineAndInfluence";			// �T�v�E�e��
$sql .= ", a.PassageAndCorrespondence";			// �o�߁E�Ή�
$sql .= ", a.TellingPresence";				// ���񍐗L��
$sql .= ", a.TellingDate";				// ���񍐓���
$sql .= ", a.ReportWithinNextDay";			// �����ȓ��񍐗L��
$sql .= " FROM ObstaclePhenomenonTBL a, ImportanceTBL b";
$sql .= " WHERE a.CorrectionMeasureNumber = '".$CMNum."'";
$sql .= " AND a.ImportanceCode = b.ImportanceCode";

// SQL���s
$result = odbc_exec($conn_id, $sql);
?>
<table border="0" width="100%">
<tr>
	<th align="left">��Q����</th>
</tr>
<tr>
	<td>
		<table rules="all">
		<tr>
			<th class="Detail_DataItem">��Q�敪</th>
			<td class="Detail_DataItem">�f�[�^�R�O</td>
		</tr>
		</table>
		<table width="100%" rules="all">
		<tr>
			<th class="Detail_DataItem">��Q���e</th>
<?php
$wk   = odbc_result($result, "ObstacleContents");
print "<td class=\"Detail_DataItem\">".NullDataChenge($wk)."</td>";
?>
		</tr>
		</table>
		<table rules="all">
		<tr>
			<th class="Detail_DataItem">�����i���m�j����</th>
<?php
$wk   = DBTime2PHPTime(odbc_result($result, "OccurrenceDate"));
print "<td class=\"Detail_DataItem\">".NullDataChenge(StrFTime("%Y/%m/%d %H:%M", $wk))."</td>";
?>
		</tr>
		</table>
		<table rules="all">
		<tr>
			<th class="Detail_DataItem">�Ɩ��e��</th>
<?php
$wk   = odbc_result($result, "BusinessInfluentialPresence");
if($wk == "10") {
	print "<td class=\"Detail_DataItem\">�L��</td>";
} else {
	print "<td class=\"Detail_DataItem\">����</td>";
}
?>
		</tr>
		</table>
		<table rules="all">
		<tr>
			<th class="Detail_DataItem">�d�v�x</th>
<?php
$wk   = odbc_result($result, "ImportanceName");
print "<td class=\"Detail_DataItem\">".NullDataChenge($wk)."</td>";
?>
		</tr>
		</table>
		<table width="100%" rules="all">
		<tr>
			<th class="Detail_DataItem">�T�v/�e��</th>
<?php
$wk   = odbc_result($result, "OutlineAndInfluence");
print "<td class=\"Detail_DataItem\">".NullDataChenge($wk)."</td>";
?>
		</tr>
		<tr>
			<th class="Detail_DataItem">�o��/�Ή�</th>
<?php
$wk   = odbc_result($result, "PassageAndCorrespondence");
print "<td class=\"Detail_DataItem\">".NullDataChenge($wk)."</td>";
?>
		</tr>
		</table>
		<table rules="all">
		<tr>
			<th class="Detail_DataItem">1���Ԉȓ��񍐁i���j</th>
<?php
$wk   = odbc_result($result, "TellingPresence");
if($wk == "10") {
	print "<td class=\"Detail_DataItem\">�L��</td>";
} else {
	print "<td class=\"Detail_DataItem\">����</td>";
}
?>
			<th class="Detail_DataItem">����</th>
<?php
$wk   = DBTime2PHPTime(odbc_result($result, "TellingDate"));
print "<td class=\"Detail_DataItem\">".NullDataChenge(StrFTime("%Y/%m/%d %H:%M", $wk))."</td>";
?>
		</tr>
		</table>
		<table rules="all">
		<tr>
			<th class="Detail_DataItem">�����ȓ��񍐁i�����j</th>
<?php
$wk   = odbc_result($result, "ReportWithinNextDay");
if($wk == "10") {
	print "<td class=\"Detail_DataItem\">�L��</td>";
} else {
	print "<td class=\"Detail_DataItem\">����</td>";
}
?>
		</tr>
		</table>
	</td>
</tr>
</table>
<?php
DB_CLOSE($conn_id);
?>

<!-- �������� -->
<?php
$conn_id = DB_OPEN();

// SQL���̐���
$sql  = "SELECT";
$sql .= " a.DirectCause";
$sql .= ", a.UndiscoveredReason";
$sql .= ", a.FoundationCause";
$sql .= " FROM ObstacleAnalysisTBL a";
$sql .= " WHERE a.CorrectionMeasureNumber = '".$CMNum."'";

// SQL���s
$result = odbc_exec($conn_id, $sql);
?>
<br>
<table border="0" cellpadding="0" cellspacing="1" width="100%">
<tr>
	<th align="left">��������</th>
</tr>
<tr>
	<td>
		<table rules="all">
		<tr>
			<th class="Detail_DataItem">���ڌ����敪</th>
			<td class="Detail_DataItem">�f�[�^�S�P</td>
		</tr>
		</table>
		<table width="100%" rules="all">
		<tr>
			<th class="Detail_DataItem">���ڌ���</th>
<?php
$wk   = odbc_result($result, "DirectCause");
print "<td class=\"Detail_DataItem\">".NullDataChenge($wk)."</td>";
?>
		</tr>
		<tr>
			<th class="Detail_DataItem">���������R</th>
<?php
$wk   = odbc_result($result, "UndiscoveredReason");
print "<td class=\"Detail_DataItem\">".NullDataChenge($wk)."</td>";
?>
		</tr>
		<table rules="all">
		<tr>
			<th class="Detail_DataItem">���{�����敪</th>
			<td class="Detail_DataItem">�f�[�^�S�S</td>
		</tr>
		</table>
		<table width="100%" rules="all">
		<tr>
			<th class="Detail_DataItem">���{����</th>
<?php
$wk   = odbc_result($result, "FoundationCause");
print "<td class=\"Detail_DataItem\">".NullDataChenge($wk)."</td>";
?>
		</tr>
		</table>
	</td>
</tr>
</table>
<?php
DB_CLOSE($conn_id);
?>

<!-- �����[�u -->
<?php
$conn_id = DB_OPEN();

// SQL���̐���
$sql  = "SELECT";
$sql .= " a.CorrectionContents";
$sql .= ", a.CorrectionPlanOutline";
$sql .= ", a.CorrectionPlanResults";
$sql .= " FROM CorrectionContentsTBL a";
$sql .= " WHERE a.CorrectionMeasureNumber = '".$CMNum."'";

// SQL���s
$result = odbc_exec($conn_id, $sql);
?>
<br>
<table border="0" cellpadding="0" cellspacing="1" width="100%">
<tr>
	<th align="left">�����[�u</th>
</tr>
<tr>
	<td>
		<table width="100%" rules="all">
		<tr>
			<th class="Detail_DataItem">�������e</th>
<?php
$wk   = odbc_result($result, "CorrectionContents");
print "<td class=\"Detail_DataItem\">".NullDataChenge($wk)."</td>";
?>
		</tr>
		<tr>
			<th class="Detail_DataItem">�����v��T�v</th>
<?php
$wk   = odbc_result($result, "CorrectionPlanOutline");
print "<td class=\"Detail_DataItem\">".NullDataChenge($wk)."</td>";
?>
		</tr>
		<tr>
			<th class="Detail_DataItem">�����v�����</th>
<?php
$wk   = odbc_result($result, "CorrectionPlanResults");
print "<td class=\"Detail_DataItem\">".NullDataChenge($wk)."</td>";
?>
		</tr>
		</table>
	</td>
</tr>
</table>
<?php
DB_CLOSE($conn_id);
?>

<!-- �����[�u���� -->
<?php
$conn_id = DB_OPEN();

// SQL���̐���
$sql  = "SELECT";
$sql .= " a.ConfirmationMeans";
$sql .= ", a.ConfirmationTime";
$sql .= ", a.ConfirmationResult";
$sql .= " FROM CorrectionContentsTBL a";
$sql .= " WHERE a.CorrectionMeasureNumber = '".$CMNum."'";

// SQL���s
$result = odbc_exec($conn_id, $sql);
?>
<br>
<table border="0" cellpadding="0" cellspacing="0" width="100%">
<tr>
	<th align="left">�����[�u���ʁi�L�����m�F�E�]���j</th>
</tr>
<tr>
	<td>
		<table width="100%" rules="all">
		<tr>
			<th class="Detail_DataItem">�m�F��i</th>
<?php
$wk   = odbc_result($result, "ConfirmationMeans");
print "<td class=\"Detail_DataItem\">".NullDataChenge($wk)."</td>";
?>
		</tr>
		<tr>
			<th class="Detail_DataItem">�m�F����</th>
<?php
$wk   = odbc_result($result, "ConfirmationTime");
print "<td class=\"Detail_DataItem\">".NullDataChenge($wk)."</td>";
?>
		</tr>
		</table>
		<table rules="all">
		<tr>
			<th class="Detail_DataItem">��������</th>
			<td class="Detail_DataItem">�f�[�^�U�R</td>
		</tr>
		</table>
		<table width="100%" rules="all">
		<tr>
			<th class="Detail_DataItem">�m�F����</th>
<?php
$wk   = odbc_result($result, "ConfirmationResult");
print "<td class=\"Detail_DataItem\">".NullDataChenge($wk)."</td>";
?>
		</tr>
		</table>
	</td>
</tr>
</table>
<?php
DB_CLOSE($conn_id);
?>

<!-- ���l -->
<?php
$conn_id = DB_OPEN();

// SQL���̐���
$sql  = "SELECT";
$sql .= " a.Note";
$sql .= " FROM ItemTBL a";
$sql .= " WHERE a.CorrectionMeasureNumber = '".$CMNum."'";

// SQL���s
$result = odbc_exec($conn_id, $sql);
?>
<br>
<table border="0" cellpadding="0" cellspacing="0" width="100%">
<tr>
	<th align="left">���l</th>
</tr>
<tr>
	<td>
		<table width="100%" rules="all">
		<tr>
<?php
$wk   = odbc_result($result, "Note");
print "<td class=\"Detail_DataItem\">".NullDataChenge($wk)."</td>";
?>
		</tr>
		</table>
	</td>
</tr>
</table>
<?php
DB_CLOSE($conn_id);
?>

<!-- �Г���� -->
<?php
$conn_id = DB_OPEN();

// SQL���̐���
$sql  = "SELECT";
$sql .= " b.ContractConfirmation AS ContractConfirmation";
$sql .= ", a.OperationalNotificationNumber AS OperationalNotificationNumber";
$sql .= ", b.AppropriationDepartmentOfSales AS AppropriationDepartmentOfSales";
$sql .= " FROM ItemTBL a, OperationalNoticeTBL b";
$sql .= " WHERE a.CorrectionMeasureNumber = '".$CMNum."'";
$sql .= " AND a.OperationalNotificationNumber = b.OperationalNotificationNumber";

// SQL���s
$result = odbc_exec($conn_id, $sql);
?>
<br>
<table border="0" cellpadding="0" cellspacing="1">
<tr>
	<th align="left">��Q������Ƃ̌_��`��</th>
</tr>
	<td>
		<table rules="all">
		<tr>
			<th class="Detail_DataItem2">�_��`��</th>
			<th class="Detail_DataItem2">��ƒʒm���ԍ�</th>
			<th class="Detail_DataItem2">����v�㕔��</th>
		</tr>
		<tr>
<?php
$wk1 = odbc_result($result, "ContractConfirmation");
$wk2 = odbc_result($result, "OperationalNotificationNumber");
$wk3 = odbc_result($result, "AppropriationDepartmentOfSales");
print "<td class=\"Detail_DataItem\">".NullDataChenge($wk1)."</td>";
print "<td class=\"Detail_DataItem\">".NullDataChenge($wk2)."</td>";
print "<td class=\"Detail_DataItem\">".NullDataChenge($wk3)."</td>";
?>
		</tr>
		</table>
	</td>
</tr>
</table>
<?php
DB_CLOSE($conn_id);
?>

</body>

</html>
