<?php
require_once("CorrectionMeasureMgmt.php");
?>

<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01//EN">
<HTML LANG="ja">
<HEAD>
<LINK REL="stylesheet" HREF="CorrectionCommon.css" type="text/css">
<META HTTP-EQUIV="Content-Type" CONTENT="text/html; charset=shift_jis">
<META HTTP-EQUIV="Pragma" content="no-cache">
<META HTTP-EQUIV="Cache-Control" content="no-cache">
<META HTTP-EQUIV="Pragma-Directive" content="no-cache">
<META HTTP-EQUIV="Cache-Directive" content="no-cache">
<TITLE>�����[�u�Ǘ� - �����[�u���� -</TITLE>
</HEAD>

<body>
<?php
$CMNum = $_GET["CMNum"]
?>

<!-- �����N�� -->
<table>
<tr><td><a href="ListIndicationScreen.html">�ꗗ�\��</a> | <a href="FaultRegistrationScreen.php">�V�K�o�^</a> | <a href="In-depthIndicationScreen.php?CMNum=<?php print $CMNum; ?>">�ڍו\��</a> | <a href="ObstaclePhenomenonInputScreen.php?TYPE=Renewal&CMNum=<?php print $CMNum; ?>">��Q���e����</a> | <a href="CorrectionMeasureInputScreen.php?CMNum=<?php print $CMNum; ?>">�����[�u����</a> | <a href="CorrectionResultInputScreen.php?CMNum=<?php print $CMNum; ?>">�������ʓ���</a></td></tr>
</table>
<br>

<!-- ���ʏ�� -->
<table border="0" width="100%">
<tr>
	<td width="50%">
		<table border="0" cellpadding="0">
		<tr>
			<td>
				<table border="1" class="Emphasis" align="left" rules="all">
				<tr>
					<th class="Detail_IDItem">�����[�u�ԍ�</th>
					<td class="Detail_IDItem">�f�[�^�O�O</td>
				</tr>
				</table>
			</td>
		</tr>
		<tr>
			<td>
				<table border="1" class="Emphasis" align="left" rules="all">
				<tr>
					<th class="Detail_IDItem">��������</th>
					<td class="Detail_IDItem2">�f�[�^�O�P</td>
				</tr>
				</table>
			</td>
		</tr>
		</table>
	</td>
	<td width="50%">
		<table border="1" cellpadding="0" cellspacing="1" align="right">
		<tr>
			<th class="Detail_ControlItem">��Q�Ǘ��ԍ�</th>
			<td class="Detail_ControlItem">�f�[�^�P�P</td>
		</tr>
		<tr>
			<th class="Detail_ControlItem">�S������</th>
			<td class="Detail_ControlItem">�f�[�^�P�Q</td>
		</tr>
		<tr>
			<th class="Detail_ControlItem">�S����</th>
			<td class="Detail_ControlItem">�f�[�^�P�R</td>

		</tr>
		</table>
	</td>
</tr>
</table>

<!-- �Ǘ����� -->
<br>
<table border="1" rules="all">
<tr>
	<th class="Detail_DataItem">�������F��</th>
	<td>
		<input type="text" name="InnerApprovalDayYear" value="" size="4" />
		�N
		<select name="InnerApprovalDayMonth">
			<option value=""></option>
			<option value="1">1</option>
			<option value="2">2</option>
			<option value="3">3</option>
			<option value="4">4</option>
			<option value="5">5</option>
			<option value="6">6</option>
			<option value="7">7</option>
			<option value="8">8</option>
			<option value="9">9</option>
			<option value="10">10</option>
			<option value="11">11</option>
			<option value="12">12</option>
		</select>
		��
		<select name="InnerApprovalDayDay">
			<option value=""></option>
			<option value="1">1</option>
			<option value="2">2</option>
			<option value="3">3</option>
			<option value="4">4</option>
			<option value="5">5</option>
			<option value="6">6</option>
			<option value="7">7</option>
			<option value="8">8</option>
			<option value="9">9</option>
			<option value="10">10</option>
			<option value="11">11</option>
			<option value="12">12</option>
			<option value="13">13</option>
			<option value="14">14</option>
			<option value="15">15</option>
			<option value="16">16</option>
			<option value="17">17</option>
			<option value="18">18</option>
			<option value="19">19</option>
			<option value="20">20</option>
			<option value="21">21</option>
			<option value="22">22</option>
			<option value="23">23</option>
			<option value="24">24</option>
			<option value="25">25</option>
			<option value="26">26</option>
			<option value="27">27</option>
			<option value="28">28</option>
			<option value="29">29</option>
			<option value="30">30</option>
			<option value="31">31</option>
		</select>
		��
	</td>
</tr>
</table>
<table border="1" rules="all">
<tr>
	<th class="Detail_DataItem">�S���A���F��</th>
	<td>
		<input type="text" name="NMIFOfACApprovalDayYear" value="" size="4" />
		�N
		<select name="NMIFOfACApprovalDayMonth">
			<option value=""></option>
			<option value="1">1</option>
			<option value="2">2</option>
			<option value="3">3</option>
			<option value="4">4</option>
			<option value="5">5</option>
			<option value="6">6</option>
			<option value="7">7</option>
			<option value="8">8</option>
			<option value="9">9</option>
			<option value="10">10</option>
			<option value="11">11</option>
			<option value="12">12</option>
		</select>
		��
		<select name="NMIFOfACApprovalDayDay">
			<option value=""></option>
			<option value="1">1</option>
			<option value="2">2</option>
			<option value="3">3</option>
			<option value="4">4</option>
			<option value="5">5</option>
			<option value="6">6</option>
			<option value="7">7</option>
			<option value="8">8</option>
			<option value="9">9</option>
			<option value="10">10</option>
			<option value="11">11</option>
			<option value="12">12</option>
			<option value="13">13</option>
			<option value="14">14</option>
			<option value="15">15</option>
			<option value="16">16</option>
			<option value="17">17</option>
			<option value="18">18</option>
			<option value="19">19</option>
			<option value="20">20</option>
			<option value="21">21</option>
			<option value="22">22</option>
			<option value="23">23</option>
			<option value="24">24</option>
			<option value="25">25</option>
			<option value="26">26</option>
			<option value="27">27</option>
			<option value="28">28</option>
			<option value="29">29</option>
			<option value="30">30</option>
			<option value="31">31</option>
		</select>
		��
	</td>
</tr>
</table>

<table border="1" rules="all">
<tr>
	<th class="Detail_DataItem">�����[�u�����\���</th>
	<td>
		<input type="text" name="CorrectionMeasureA-dayYear" value="" size="4" />
		�N
		<select name="CorrectionMeasureA-dayMonth">
			<option value=""></option>
			<option value="1">1</option>
			<option value="2">2</option>
			<option value="3">3</option>
			<option value="4">4</option>
			<option value="5">5</option>
			<option value="6">6</option>
			<option value="7">7</option>
			<option value="8">8</option>
			<option value="9">9</option>
			<option value="10">10</option>
			<option value="11">11</option>
			<option value="12">12</option>
		</select>
		��
		<select name="CorrectionMeasureA-dayDay">
			<option value=""></option>
			<option value="1">1</option>
			<option value="2">2</option>
			<option value="3">3</option>
			<option value="4">4</option>
			<option value="5">5</option>
			<option value="6">6</option>
			<option value="7">7</option>
			<option value="8">8</option>
			<option value="9">9</option>
			<option value="10">10</option>
			<option value="11">11</option>
			<option value="12">12</option>
			<option value="13">13</option>
			<option value="14">14</option>
			<option value="15">15</option>
			<option value="16">16</option>
			<option value="17">17</option>
			<option value="18">18</option>
			<option value="19">19</option>
			<option value="20">20</option>
			<option value="21">21</option>
			<option value="22">22</option>
			<option value="23">23</option>
			<option value="24">24</option>
			<option value="25">25</option>
			<option value="26">26</option>
			<option value="27">27</option>
			<option value="28">28</option>
			<option value="29">29</option>
			<option value="30">30</option>
			<option value="31">31</option>
		</select>
		��
	</td>
</tr>
</table>

<br>

<!-- ��Q���� -->
<table border="1" width="100%" rules="all">
<tr>
	<th class="Detail_DataItem">��Q���e</th>
	<td class="Detail_DataItem">�f�[�^�R�P</td>
</tr>
</table>

<!-- �����[�u -->
<br>
<table border="0">
<tr>
	<th align="left">�����[�u</th>
</tr>
<tr>
	<td>
		<table border="1" rules="all">
		<tr>
			<th class="Detail_DataItem">�������e</th>
			<td>
				<textarea name="DirectCause" rows="10" cols="120" wrap="virtuala"></textarea>
			</td>
		</tr>
		<tr>
			<th class="Detail_DataItem">�����v��T�v</th>
			<td>
				<textarea name="UndiscoveredReason" rows="10" cols="120" wrap="virtuala"></textarea>
			</td>
		</tr>
	</td>
</tr>
</table>
<!-- �����[�u�m�F���@ -->
<br>
<table border="0" cellpadding="0" cellspacing="1">
<tr>
	<th align="left">�����[�u�m�F���@</th>
</tr>
<tr>
	<td>
		<table border="1" rules="all">
		<tr>
			<th class="Detail_DataItem">�m�F��i</th>
			<td>
				<textarea name="DirectCause" rows="10" cols="120" wrap="virtuala"></textarea>
			</td>
		</tr>
		<tr>
			<th class="Detail_DataItem">�m�F����</th>
			<td>
				<textarea name="UndiscoveredReason" rows="10" cols="120" wrap="virtuala"></textarea>
			</td>
		</tr>
	</td>
</tr>
</table>


<!-- ���l -->
<br>
<table border="0">
<tr>
	<th align="left">���l</th>
</tr>
<tr>
	<td>
		<table border="1" width="100%" rules="all">
		<tr>
			<td>
				<textarea name="Note" rows="5" cols="135" wrap="virtuala"></textarea>
			</td>
		</tr>
		</table>
	</td>
</tr>
</table>

<!-- �X�V���s -->
<br>
<table border="0" width="100%">
<tr>
	<td align="right">
		<label>
			<button type="submit" value="Renewal">�����[�u�X�V</button>
		</label>
	</td>
</tr>
</table>
<br>
<br>
</body>

</html>
