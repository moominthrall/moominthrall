These documents TR24-J99.pdf and TR25-J99.pdf are completely japanized PDF.
To view these documents, you must have Japanese version of Adobe Acrobat 3.0J
and Japanese Operating System with Japanese fonts.

Note: Original TRs in English can be obtained following URL.

	http://www.sei.cmu.edu/activities/cmm/obtain.cmm.html

	Obtaining the Software CMM[R] v1.1

	A notebook containing two SEI technical reports comprise the Capability
	Maturity Model for Software. The citations for the current versions of
	these two technical reports are:

	Mark C. Paulk, Bill Curtis, Mary Beth Chrissis, and Charles V. Weber,
	"Capability Maturity Model for Software, Version 1.1", Software
	Engineering Institute, CMU/SEI-93-TR-24, DTIC Number ADA263403,
	February 1993.

	Mark C. Paulk, Charles V. Weber, Suzanne M. Garcia, Mary Beth
	Chrissis, and Marilyn W. Bush, "Key Practices of the Capability Maturity
	Model, Version 1.1", Software Engineering Institute, CMU/SEI-93-TR-25,
	DTIC Number ADA263432, February 1993.

[R] CMM, Capability Maturity Model, Capability Maturity Modeling
    are registered in the U.S. Patent and Trademark Office.

-------------------
1999.05.06 Software Engineers Association.	Thu May  6 22:35:21 EST 1999


